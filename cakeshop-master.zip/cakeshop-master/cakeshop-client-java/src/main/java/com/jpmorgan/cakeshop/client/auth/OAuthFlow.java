package com.jpmorgan.cakeshop.client.auth;

public enum OAuthFlow {
    accessCode, implicit, password, application
}