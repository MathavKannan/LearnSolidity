package com.jpmorgan.cakeshop.client.proxy;

public interface ValueConstants {
    public static final String DEFAULT_NONE = "\n\t\t\n\t\t\n\uE000\uE001\uE002\n\t\t\t\t\n";
}
