import React from 'react';
import ReactDOM from 'react-dom';
import Manage from './components/Manage'


ReactDOM.render(<Manage />,
    document.getElementById('app')
);
