package com.jpmorgan.cakeshop.metrics;

public interface TickListener {
    public void nextTick(double val);
}
