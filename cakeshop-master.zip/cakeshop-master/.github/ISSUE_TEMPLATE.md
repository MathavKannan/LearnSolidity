
#### Description of problem


#### Expected behavior


#### Actual behavior

(paste logs at end)

#### Steps to reproduce the behavior


#### System information

Cakeshop version or commit hash: [version]

Cakeshop runtime configuration: [stand alone or attach mode]

Geth/Quorum version testing against: [run `geth version` or copy from Node Info in UI]

Cakeshop OS & Version: Windows/Linux/OSX

Browser OS & Version: Windows/Linux/OSX MSIE/Chrome/Firefox/Safari

#### Backtrace/logs

Copy all relevant log output. Use [Gist](https://gist.github.com/) for longer logs.

```
[stacktrace/logs]
```
