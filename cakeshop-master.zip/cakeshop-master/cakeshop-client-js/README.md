
### Compiling JS Client

```
cd src/main/javascript
npm install && ./node_modules/.bin/bower install
./node_modules/.bin/gulp install
```
